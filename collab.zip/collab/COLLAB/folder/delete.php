<?php

include('inc/db.php');

if(isset($_GET['del'])) {
    $path = $_GET['del'];
    unlink($path);
    $res = mysqli_query($con,"DELETE FROM documents WHERE path='$path'");
    header("Location:../login/index.php");
}

?>

