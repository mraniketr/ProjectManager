<?php

$user = 'u977017150_root';
$pass = '12345678';
$db='u977017150_collab';
$error = "error";
$con = mysqli_connect('mysql.hostinger.com',$user,$pass) or die($error);
mysqli_select_db($con,$db) or die($error);

?>